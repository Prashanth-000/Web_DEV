function mytime(){
    const now=new Date();
    let thour=now.getHours();
    let ampm=(thour>=12)?'PM':'AM';
    let xhour=(thour>12)?(thour%12):thour;
    const tmin=now.getMinutes().toString().padStart(2,0);
    const tsec=now.getSeconds().toString().padStart(2,0);
    const res=` ${xhour}:${tmin}:${tsec}:${ampm}`;
    document.getElementById("clock").textContent=res;

}
setInterval(mytime,1000);
